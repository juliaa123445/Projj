from flask import Flask, render_template, request, redirect, url_for, flash, session, make_response, jsonify
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Przykładowa baza użytkowników
users_db = {
    'admin': {'password': 'adminpass', 'role': 'admin'},
    'user1': {'password': 'userpass', 'role': 'user'}
}

surveys_db = {}

def is_admin():
    return session.get('username') and users_db.get(session['username'], {}).get('role') == 'admin'

@app.route('/', methods=['GET', 'POST'])
def main():
    if request.method == 'POST':
        if 'login' in request.form:
            # Logowanie
            username = request.form['username']
            password = request.form['password']

            if username not in users_db:
                flash('User does not exist. Please register first.', 'error')
            elif users_db[username]['password'] != password:
                flash('Incorrect password. Please try again.', 'error')
            else:
                session['username'] = username
                return redirect(url_for('create_survey') if is_admin() else url_for('vote'))

        elif 'register' in request.form:
            # Rejestracja
            username = request.form.get('username')
            password = request.form.get('password')

            if username in users_db:
                flash('Username already exists. Please choose a different username.', 'error')
            else:
                users_db[username] = {'password': password, 'role': 'user'}
                flash('Registration successful! Please log in.', 'success')
                return redirect(url_for('main'))

    return render_template('main.html')


@app.route('/logout')
def logout():
    session.pop('username', None)
    flash('Logged out successfully!', 'success')
    return redirect(url_for('main'))


@app.route('/create_survey', methods=['GET', 'POST'])
def create_survey():
    if not is_admin():
        flash('Only admins can create surveys!', 'error')
        return redirect(url_for('main'))

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        start_time = request.form['start_time']
        end_time = request.form['end_time']
        scale = int(request.form['scale'])

        options = [request.form.get(f'option_{i}') for i in range(1, scale + 1)]

        try:
            start_time_dt = datetime.strptime(start_time, "%Y-%m-%dT%H:%M")
            end_time_dt = datetime.strptime(end_time, "%Y-%m-%dT%H:%M")
            current_time = datetime.now()

            if end_time_dt <= start_time_dt or end_time_dt <= current_time:
                flash('Invalid end time. Please ensure it is after the start time and in the future.', 'error')
                return render_template('create_survey.html', surveys=surveys_db)

            survey_id = len(surveys_db) + 1
            surveys_db[survey_id] = {
                'title': title,
                'description': description,
                'start_time': start_time_dt,
                'end_time': end_time_dt,
                'scale': scale,
                'options': options,
                'votes': {i: 0 for i in range(1, scale + 1)},
                'voters': []
            }
            flash('Survey created successfully!', 'success')
            return redirect(url_for('create_survey'))
        except ValueError:
            flash('Invalid date or time format.', 'error')
            return render_template('create_survey.html', surveys=surveys_db)

    return render_template('create_survey.html', surveys=surveys_db)


@app.route('/vote', methods=['GET', 'POST'])
def vote():
    if 'username' not in session:
        flash('Please log in to vote.', 'error')
        return redirect(url_for('main'))

    if request.method == 'POST':
        survey_id = int(request.form['survey_id'])
        score = int(request.form['score'])
        survey = surveys_db.get(survey_id)

        if survey:
            current_time = datetime.now()
            if current_time < survey['start_time']:
                flash(f"The survey will start on {survey['start_time'].strftime('%Y-%m-%d %H:%M')}. Voting is not available yet.", 'error')
            elif session['username'] in survey['voters']:
                flash('You have already voted in this survey.', 'error')
            else:
                survey['votes'][score] += 1
                survey['voters'].append(session['username'])
                flash('Your vote has been submitted!', 'success')
        else:
            flash('Invalid vote. Please try again.', 'error')

    return render_template('vote.html', surveys=surveys_db)


@app.route('/report/<int:survey_id>')
def report(survey_id):
    if not is_admin():
        flash('Only admins can generate reports!', 'error')
        return redirect(url_for('main'))

    survey = surveys_db.get(survey_id)
    if not survey:
        flash('Survey not found!', 'error')
        return redirect(url_for('create_survey'))

    report_data = f"Survey Report: {survey['title']}\n\nDescription: {survey['description']}\n\n"
    report_data += f"Time: {survey['start_time']} to {survey['end_time']}\n\nOptions:\n"
    for option, count in zip(survey['options'], survey['votes'].values()):
        report_data += f"{option}: {count} votes\n"

    response = make_response(report_data)
    response.headers["Content-Disposition"] = f"attachment; filename=report_{survey_id}.txt"
    return response


@app.route('/api/votes')
def api_votes():
    data = []
    for survey_id, survey in surveys_db.items():
        for score, count in survey['votes'].items():
            option_name = survey['options'][score - 1] if survey['options'] else f'Opcja {score}'
            data.append({'survey_id': survey_id, 'score': option_name, 'votes': count})
    return jsonify(data)


if __name__ == '__main__':
    app.run(debug=True)
