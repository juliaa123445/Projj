from flask import Flask, render_template, request, redirect, url_for, flash, session, make_response, jsonify
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from models import db, User, Survey, Option, Vote

app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
migrate = Migrate(app, db)


def is_admin():
    """Check if the logged-in user is an admin."""
    username = session.get('username')
    if not username:
        return False
    user = User.query.filter_by(username=username).first()
    return user is not None and user.role == 'admin'


@app.route('/', methods=['GET', 'POST'])
def main():
    if request.method == 'POST':
        if 'login' in request.form:
            # Logowanie
            username = request.form['username']
            password = request.form['password']
            user = User.query.filter_by(username=username).first()

            if user is None:
                flash('User does not exist. Please register first.', 'error')
            elif not user.check_password(password):
                flash('Incorrect password. Please try again.', 'error')
            else:
                session['username'] = username
                return redirect(url_for('create_survey') if user.role == 'admin' else url_for('vote'))

        elif 'register' in request.form:
            # Rejestracja
            username = request.form.get('username')
            password = request.form.get('password')

            if User.query.filter_by(username=username).first():
                flash('Username already exists. Please choose a different username.', 'error')
            else:
                user = User(username=username)
                user.set_password(password)
                db.session.add(user)
                db.session.commit()
                flash('Registration successful! Please log in.', 'success')
                return redirect(url_for('main'))

    return render_template('main.html')


@app.route('/logout')
def logout():
    session.pop('username', None)
    flash('Logged out successfully!', 'success')
    return redirect(url_for('main'))


@app.route('/create_survey', methods=['GET', 'POST'])
def create_survey():
    if not is_admin():
        flash('Only admins can create surveys!', 'error')
        return redirect(url_for('main'))

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        start_time = request.form['start_time']
        end_time = request.form['end_time']
        scale = int(request.form['scale'])

        options = [request.form.get(f'option_{i}') for i in range(1, scale + 1)]

        try:
            start_time_dt = datetime.strptime(start_time, "%Y-%m-%dT%H:%M")
            end_time_dt = datetime.strptime(end_time, "%Y-%m-%dT%H:%M")
            current_time = datetime.now()

            if end_time_dt <= start_time_dt or end_time_dt <= current_time:
                flash('Invalid end time. Please ensure it is after the start time and in the future.', 'error')
                return render_template('create_survey.html')

            survey = Survey(title=title, description=description, start_time=start_time_dt, end_time=end_time_dt,
                            scale=scale)
            db.session.add(survey)
            db.session.commit()

            for option_text in options:
                if option_text:
                    option = Option(option_text=option_text, survey_id=survey.id)
                    db.session.add(option)
            db.session.commit()

            flash('Survey created successfully!', 'success')
            return redirect(url_for('create_survey'))
        except ValueError:
            flash('Invalid date or time format.', 'error')
            return render_template('create_survey.html')

    return render_template('create_survey.html',surveys=Survey.query.all())


@app.route('/vote', methods=['GET', 'POST'])
def vote():
    if 'username' not in session:
        flash('Please log in to vote.', 'error')
        return redirect(url_for('main'))

    user = User.query.filter_by(username=session['username']).first()
    if request.method == 'POST':
        survey_id = int(request.form['survey_id'])
        option_id = int(request.form['score'])
        survey = Survey.query.get(survey_id)

        if survey:
            current_time = datetime.now()
            if current_time < survey.start_time:
                flash(f"The survey will start on {survey.start_time}.", 'error')
            elif Vote.query.filter_by(user_id=user.id, survey_id=survey_id).first():
                flash('You have already voted in this survey.', 'error')
            else:
                vote = Vote(user_id=user.id, survey_id=survey_id, option_id=option_id)
                db.session.add(vote)
                db.session.commit()
                flash('Your vote has been submitted!', 'success')
        else:
            flash('Invalid survey.', 'error')

    return render_template('vote.html', surveys=Survey.query.all())


@app.route('/report/<int:survey_id>')
def report(survey_id):
    if not is_admin():
        flash('Only admins can generate reports!', 'error')
        return redirect(url_for('main'))

    survey = Survey.query.get(survey_id)
    if not survey:
        flash('Survey not found!', 'error')
        return redirect(url_for('create_survey'))

    report_data = f"Survey Report: {survey.title}\n\nDescription: {survey.description}\n\n"
    report_data += f"Time: {survey.start_time} to {survey.end_time}\n\nOptions:\n"
    for option in survey.options:
        vote_count = Vote.query.filter_by(survey_id=survey.id, option_id=option.id).count()
        report_data += f"{option.option_text}: {vote_count} votes\n"

    response = make_response(report_data)
    response.headers["Content-Disposition"] = f"attachment; filename=report_{survey_id}.txt"
    return response


@app.route('/api/votes')
def api_votes():
    data = []
    surveys = Survey.query.all()

    for survey in surveys:
        for option in survey.options:
            vote_count = Vote.query.filter_by(survey_id=survey.id, option_id=option.id).count()
            data.append({
                'survey_id': survey.id,
                'score': option.option_text,
                'votes': vote_count
            })
    return jsonify(data)


if __name__ == '__main__':
    app.run(debug=True)
