﻿$(document).ready(function () {
    $('.modal-content').hide();

    $('.menu-button').on('click', function () {
        const target = $(this).attr('id').replace('-button', '-content');
        $('.modal-content').hide();
        $('#' + target).fadeIn();
    });

    $(window).on('click', function (event) {
        if ($(event.target).hasClass('modal-content')) {
            $('.modal-content').fadeOut();
        }
    });

    $('.menu-button').hover(function(){
        $(this).animate({padding: '12px 24px'}, 200);
    }, function(){
        $(this).animate({padding: '10px 20px'}, 200);
    });

    $('.menu-button').on('click', function () {
        $('#flash-messages').fadeOut();
    });

    setTimeout(function() {
        $('#flash-messages').fadeOut('slow');
    }, 5000);

    $('#scale').on('change', function () {
        const selectedScale = parseInt($(this).val());

        $('#options-container .option-field').each(function (index) {
            if (index < selectedScale) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    }).trigger('change');

    // Przechwytywanie formularza głosowania (tylko dla formularzy z name="vote-form")
    $('form[name="vote-form"]').on('submit', function (event) {
        event.preventDefault(); // Zatrzymuje domyślne przesyłanie formularza

        const formData = $(this).serialize();

        // Wysyła głos przez AJAX
        $.post('/vote', formData, function (response) {
            // Obsługuje odpowiedź bez przeładowania strony i bez wyświetlania JSON-a
            if (response.flash_messages) {
                $('#flash-messages').html('');
                response.flash_messages.forEach(function(message) {
                    $('#flash-messages').append(`<div class="flash-message ${message[0]}">${message[1]}</div>`);
                });
            }

            // Aktualizuje wykresy po oddaniu głosu
            updateCharts();
        }).fail(function() {
            console.error("Error processing vote submission.");
        });
    });
});

function closeModal(modalId) {
    $('#' + modalId).fadeOut();
}

const charts = {};

function createChart(surveyId, labels, data) {
    const ctx = document.getElementById(`votesChart${surveyId}`).getContext('2d');
    charts[surveyId] = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Votes',
                data: data,
                backgroundColor: 'rgba(75, 192, 192, 0.6)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    grid: { display: false }
                },
                y: {
                    beginAtZero: true,
                    title: { display: true, text: 'Ilość głosów' },
                    grid: { color: '#ddd' },
                    ticks: {
                        stepSize: function(context) {
                            const maxVotes = Math.max(...data);
                            if (maxVotes > 500) return 100;
                            if (maxVotes > 100) return 50;
                            if (maxVotes > 50) return 20;
                            if (maxVotes > 20) return 10;
                            if (maxVotes > 10) return 5;
                            if (maxVotes > 5) return 2;
                            return 1;
                        }
                    }
                }
            }
        }
    });
}

function updateCharts() {
    fetch('/api/votes')
        .then(response => response.json())
        .then(data => {
            data.forEach(survey => {
                const surveyId = survey.survey_id;
                const labels = survey.votes.map(vote => vote.score); // Skale głosowania
                const votesData = survey.votes.map(vote => vote.count); // Liczba głosów dla każdej opcji

                if (charts[surveyId]) {
                    charts[surveyId].data.labels = labels;
                    charts[surveyId].data.datasets[0].data = votesData;
                    charts[surveyId].update();
                } else {
                    createChart(surveyId, labels, votesData);
                }
            });
        })
        .catch(error => console.error("Error fetching vote data:", error));
}

setInterval(updateCharts, 5000);
updateCharts();
